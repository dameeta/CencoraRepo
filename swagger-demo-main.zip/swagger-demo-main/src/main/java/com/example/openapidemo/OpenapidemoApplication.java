package com.example.openapidemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenapidemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(OpenapidemoApplication.class, args);
    }

}
