# Swagger Demo Application 
A demo project demonstrating how to use Swagger (based on OpenAPI 3.0 specification) with Spring Boot to document RestAPI.

Tech stack:
- Maven
- Java 17
- Spring Boot 3.1