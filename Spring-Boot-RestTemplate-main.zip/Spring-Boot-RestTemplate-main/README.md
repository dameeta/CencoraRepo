# SpringBootRestTemplate
 Using RestTemplate in Spring Boot Applications
