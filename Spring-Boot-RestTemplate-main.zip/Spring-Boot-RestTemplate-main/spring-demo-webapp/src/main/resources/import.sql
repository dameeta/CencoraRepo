INSERT INTO TBL_USERS (id, first_name, last_name, email, date_of_birth) VALUES (1, 'Alex', 'London', 'a@mail.com', '1990-01-01');
INSERT INTO TBL_USERS (id, first_name, last_name, email, date_of_birth) VALUES (2, 'Brian', 'NewYork', 'b@mail.com', '1990-02-02');
INSERT INTO TBL_USERS (id, first_name, last_name, email, date_of_birth) VALUES (3, 'Charles', 'Paris', 'c@mail.com', '1990-03-03');